export * from './DataMainPage';
